from pathlib import Path

import pandas as pd
from shared import INPUTS
from shiny import reactive
from shiny.express import input, ui
from shiny_validate import InputValidator, check

import seaborn as sns
from textblob import TextBlob
import numpy as np

# Import data from shared.py
from shared import df
from shiny.express import input, render, ui

app_dir = Path(__file__).parent
ui.include_css(app_dir / "styles.css")

# Page title (with some additional top padding)
ui.page_opts(title="DataSalud")

# Select input for choosing the variable to plot
ui.input_select("var", "Select use of medication", choices=['Birth Control', 'Depression', 'Anxiety', 'Weight Loss', 'Pain', 'Acne', 'Insomnia', 'Bipolar Disorder', 'Diabetes, Type 2', 'High Blood Pressure'])

# Render a bar graph of the selected variable (input.var())
@render.plot
def bar_graph():
    p = sns.barplot(data=df, x='Secondary effect', y=input.var(), color="#007bc2", edgecolor="white")
    p.set_title("Side effects by use of medicine")
    return p.set(xlabel="Side effect")

with ui.card():
    ui.card_header("Patient information")
    INPUTS["name"]
    INPUTS["age"]

with ui.card():
    ui.card_header("Review of your medicine")
    INPUTS["medicinefor"]
    INPUTS["review"]

with ui.card():
    ui.card_header("Medicine rating")
    INPUTS["rating"]


ui.div(
    ui.input_action_button("submit", "Submit", class_="btn btn-primary"),
    class_="d-flex justify-content-end",
)

# Unfortunate workaround to get InputValidator to work in Express
input_validator = None


@reactive.effect
def _():
    # Add validation rules for each input that requires validation
    global input_validator
    input_validator = InputValidator()
    input_validator.add_rule("name", check.required())
    input_validator.add_rule("medicinefor", check.required())
    input_validator.add_rule("review", check.required())


@reactive.effect
@reactive.event(input.submit)
def save_to_csv():
    input_validator.enable()
    if not input_validator.is_valid():
        return

    df = pd.DataFrame([{k: input[k]() for k in INPUTS.keys()}])
    df['review'] = df['review'].str.lower()
    df['review'] = df['review'].str.strip()
    df['sentiment-TextBlob'] = df['review'].apply(lambda x: TextBlob(x).sentiment.polarity)
    df['sentiment-TextBlob-qual'] = np.where(df['sentiment-TextBlob'] >= 0, 'POSITIVE', 'NEGATIVE')

    responses = app_dir / "responses.csv"
    if not responses.exists():
        df.to_csv(responses, mode="a", header=True)
    else:
        df.to_csv(responses, mode="a", header=False)

    ui.modal_show(ui.modal(f"Form submitted. The sentiment of the review of your medicine is: {df['sentiment-TextBlob-qual'][0]}.Thank you!"))
