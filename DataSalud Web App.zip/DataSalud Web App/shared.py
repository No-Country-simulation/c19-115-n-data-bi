from shiny import ui

INPUTS = {
    "name": ui.input_text("name", "Enter your name"),
    "medicinefor": ui.input_select(
        "medicinefor",
        "Medicine for:",
        choices=['Birth Control', 'Depression', 'Anxiety', 'Weight Loss', 'Pain', 'Acne', 'Insomnia', 'Bipolar Disorder', 'Diabetes, Type 2', 'High Blood Pressure', 'Other'],
    ),
    "age": ui.input_numeric("age", "Age", None, min=0, max=120, step=1),
    "review": ui.input_text("review", "Write the review of your medicine:"),
    "rating": ui.input_radio_buttons(
        "rating",
        "How would you rate your medicine?",
        choices=[1, 2, 3, 4, 5, 6, 7 , 8, 9, 10],
        selected=[],
        inline=True,
    ),

}

from pathlib import Path

import pandas as pd

app_dir = Path(__file__).parent
df = pd.read_csv(app_dir / "secondary_effects.csv")
